<?php
  include_once 'func.php';
  isset($_GET['dev']) && isset($_GET['bookid']) or die(nf());
  // if for dev+email freeflag set to true - return yes, db setfreeflag ot false
  // else return - cannot use free book
  
  $dev = ss($_GET['dev']);
  $bookid = ss($_GET['bookid']);
  
  // check if code already used
  // if free code already exists and freeflag is set return nofreebook
$res = db()->query("SELECT free_flag FROM books_freeopt1 WHERE device_id='$dev'");
checkDBResult($res);
$row = $res->fetch_assoc();
$canuse = true;
if(!$row || (int) $row['free_flag'] != 1)
        $canuse = false;
        
if($canuse)// set flag to 2 - used
{
    // make query
    $affected = db()->query("INSERT INTO books_freeopt1 (device_id, free_flag, book_id) VALUES('$dev', 2, '$bookid') ON DUPLICATE KEY UPDATE free_flag=VALUES(free_flag), book_id=VALUES(book_id)");
    checkDBResult($affected);

     $affected or die(nf());
    
}        
        
echo canuse($canuse);

?>
