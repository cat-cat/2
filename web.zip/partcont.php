<?php


 $context=array('http' => array ('header'=> 'Range: bytes=2139-', ),);
$xcontext = stream_context_create($context);
//$str=file_get_contents("http://localhost:8080/web.ppx",FALSE,$xcontext);
$str=file_get_contents("http://localhost/sm.pdf",FALSE,$xcontext);

?>
