<?php
include_once 'func.php';
isset($_GET['dev']) or die(nf());

  $dev = ss($_GET['dev']);
  
  // check if code already used
  // if free code already exists and freeflag is set return nofreebook
$res = db()->query("SELECT free_flag FROM books_freeopt1 WHERE device_id='$dev'");
checkDBResult($res);
$row = $res->fetch_assoc();
$freeflag = $row ? $row['free_flag'] : 0;

echo "<b><freeflag>$freeflag</freeflag></b>";
?>
