<?php
include_once 'func.php';

  isset($_GET['dev']) && isset($_GET['email']) or die(nf());
  $dev = ss($_GET['dev']);
  $email = ss($_GET['email']);
  
  // check if code already used
  // if free code already exists and freeflag is set return nofreebook
$res = db()->query("SELECT free_flag FROM books_freeopt1 WHERE device_id='$dev' AND email='$email'");
checkDBResult($res);
$row = $res->fetch_assoc();
$canuse = false;
if(!$row || (int) $row['free_flag'] != 2)
        $canuse = true;
$code5 = '0';        
if($canuse) // write to database new data
{
    $codefull = md5($dev.$secret);
    
    $code5 = substr($codefull,0,5);

    // make query
    $affected = db()->query("INSERT INTO books_freeopt1 (email, device_id, free_code, free_flag) VALUES('$email', '$dev', '$code5', 0) ON DUPLICATE KEY UPDATE free_code=VALUES(free_code), email=VALUES(email), free_flag=VALUES(free_flag)");
    checkDBResult($affected);

     $affected or die(nf());
        
}
$answer = $canuse ? "yes" : "no";

// TODO:
        $subject = codeMailHeader("$_SERVER[SERVER_NAME] - код для бесплатной книги"); 
        $message = "<br />Код для бесплатной книги:
        <br />---------------------------- 
        <br /><b>$code5</b>
        <br />---------------------------- 
        <br />Это сообщение сгенерировано автоматически."; 

        $headers  = "Content-type: text/html; charset=UTF-8 \r\n"; 
        $headers .= "From: info@$_SERVER[SERVER_NAME] <info@$_SERVER[SERVER_NAME]>\r\n";
        if($remoteServer!==false && !mail($email, $subject, $message,  $headers)){ 
            error_log("***err: Sending Email Failed, Please Contact Site Admin! (info@$_SERVER[SERVER_NAME])");
            die("<b><canuse>no</canuse><code>00000</code></b>"); 
        }
        
        echo "<b><canuse>$answer</canuse><code>$code5</code></b>";  
?>