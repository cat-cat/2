<?php
    include_once("func.php");

    isset($_GET['dev']) && isset($_GET['updateid']) or die(nf());

    $dev = ss($_GET['dev']);
    $upd = ss($_GET['updateid']);

    // collect updates if there are
    $last_update = file_get_contents('./last_update.txt');
    $updates1 = '';
    $newbooks = 0;
    if(is_numeric($upd) && is_numeric($last_update))
    {
        if((int)$last_update > (int)$upd)
        {
            $path     = "updates/";                // Directory containing files
            $newFile  = "updates/saturn";            // Path to new file
//            $fType     = strtolower(substr($newFile, strpos($newFile, ".")));    // File type of files to collate (got automatically)
            $file     = @scandir($path);

            if ($file)
            {
                //echo "Copying all $fType files from '<b>$path</b>' to '<b>$newFile</b>'<br /><br />";

                foreach($file as $file)
                {
                    //if (strlen($file) < 3)                    continue;
                   // if (strtolower(substr($file, strpos($file, "."))) != $fType)    continue;
                    if (strpos($file, ".")!==false)    continue;
                    if (strtolower($path.$file) == strtolower($newFile))        continue;
                    if(intval($file)<=intval($upd)) continue;
                    
                    $f  = fopen($path.$file, "r");

                    if ($f)
                    {
                        $buff    = fread($f, filesize($path.$file));
                        $f    = fclose($f);
                        
                        $data = explode('newbookscount',$buff);
                        $newbooks += $data[1];
                        $buff = $data[0];
                        
                        $updates1 .= $buff;
//                        $f    = fopen($newFile, "a");

//                        if ($f)
//                        {
//                            fwrite($f, $buff);
//                            $f = fclose($f);
//                        }    
                    }
                }
            }      
        }      
    }

    // form purchases for dev: xml:purchases = db.getPurchasesForDevid(dev);
    $res = db()->query("SELECT book_id FROM `books_bought` WHERE device_id='$dev' AND is_bought=1");
    checkDBResult($res);
    $ids = array();
    while($row = $res->fetch_assoc())
    {
        $ids[] = $row['book_id'];
    }
    // Free result set
    $res->close();
    //$db()->next_result();        
    
    $idscount = count($ids);
    $updates2 = '';    
    if($idscount>0)
    {
        // xml write meta @boughtcount
        $updates2 = "'".implode("','",$ids)."'";
        $updates1 .= "UPDATE t_abooks  SET bought=1 WHERE abook_id IN ($updates2);";          
    }
    
    if(strlen($updates1)>0)
        $updates1 .= "INSERT OR REPLACE INTO updates (id) VALUES('$last_update')";    
        
    header('Content-Type: text/xml; charset=utf-8');   
    echo "<b><sql newbooks='$newbooks'>$updates1</sql></b>"
?>