<?php
include_once("func.php");
//DebugBreak();

 isset($_GET['bid']) && isset($_GET['dev']) && isset($_GET['bt']) or die(nf());

    $bid = ss($_GET['bid']);
    $dev = ss($_GET['dev']);
    $bt = ss($_GET['bt']);     
    
    
function bt() {
global $bid;
global $dev;
global $bt;        
$affected = db()->query("INSERT INTO books_bought (user_id, device_id, book_id, is_bought) VALUES(0, '$dev', $bid, $bt) ON DUPLICATE KEY UPDATE is_bought=$bt");
checkDBResult($affected);

     return $affected ? 'yes' : 'no';
 }
 $bt = bt();
 
echo "<r><bt>$bt</bt></r>";  
?>
