<?php
//54e09c1d54aaec9c16a467bb8e99e8b4
$hash = md5(file_get_contents("15310.png"));
//$options = array(
//                         'useragent'      => "Firefox (+http://www.firefox.org)", // who am i 
//                         'connecttimeout' => 120, // timeout on connect 
//                         'timeout'          => 120, // timeout on response 
//                         'redirect'          => 10, // stop after 10 redirects
//                         'referer'           => "http://www.google.com"
//                 );

// $request = new HttpRequest('http://example.com');
// $request->setOptions($options);
// $request->send();

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "http://test.librofon.ru/service/connect/?params[]=12345678901234567890123456789012");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_VERBOSE, 1);
curl_setopt($ch, CURLOPT_HEADER, 1);

$response = curl_exec($ch);
curl_setopt($ch, CURLOPT_URL, "http://test.librofon.ru/service/getAbookFreeAudio/?params[]=30893");
$response = curl_exec($ch);

// Then, after your curl_exec call:

$header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
$header = substr($response, 0, $header_size);
$body = substr($response, $header_size);
//    $integral = 5;
//  echo <<< _END
//  hi!
//_END;
echo $body;
?>
