<?php
include_once 'func.php';
isset($_GET['dev']) && isset($_GET['code5']) && isset($_GET['email']) or die(nf());

  $dev = ss($_GET['dev']);
  $email = ss($_GET['email']);
  $code5 = ss($_GET['code5']);
  
  // check if code already used
  // if free code already exists and freeflag is set return nofreebook
$res = db()->query("SELECT free_flag FROM books_freeopt1 WHERE device_id='$dev' AND email='$email' AND free_code='$code5'");
checkDBResult($res);
$row = $res->fetch_assoc();
$canuse = true;
if(!$row || (int) $row['free_flag'] == 2)
        $canuse = false;

if($canuse) // write to database new data
{
    // make query
    $affected = db()->query("INSERT INTO books_freeopt1 (email, device_id, free_code, free_flag) VALUES('$email', '$dev', '$code5', 1) ON DUPLICATE KEY UPDATE free_code=VALUES(free_code), email=VALUES(email), free_flag=VALUES(free_flag)");
    checkDBResult($affected);

     $affected or die(nf());        
}

        
echo canuse($canuse);
?>
