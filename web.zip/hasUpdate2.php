<?php
$i = 25;
  echo <<<_END
<abooks>
<update>2013-01-22 02:00</update>
</abooks>
_END;
?>
