<?php
include_once 'func.php';


 isset($_GET['bid']) && isset($_GET['ch']) or die(nf());

    $bid = ss($_GET['bid']);
    $chnum = ss($_GET['ch']);     
    
    
 function bt($bid, $chnum) {
         $query=
    "SELECT is_bought FROM books.books_bought WHERE user_id=0 AND device_id=0 AND book_id = $bid";
        
    $db_result=db()->query($query);
    checkDBResult($db_result);
    $row=$db_result->fetch_row();

     return $row ? true : false;
 }
// find chapter
   $path = chaex($bid, $chnum) or die(nf());  
   //unlink(dirname(__FILE__).'/fileswork/'.$_POST['id'].'.'.$file);
    $bought = bt($bid, $chnum);     
                                                      
    // check if chapter bought
    // compose xml to return
   // <bought>1 or 0</bought>

// headers

// ...
echo <<<_END
<r><book id="$bid"><chapter_path id="$chnum">$baseUrl$path</chapter_path><bought>$bought</bought></book></r>
_END;

  
?>


