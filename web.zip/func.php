<?php
    $secret = "dd72b81";
    function canuse($canuse) {
        $answer = $canuse ? "yes" : "no";
        return "<b><canuse>$answer</canuse></b>";
    }
    $db; // will be initialized in db()
    function checkDBResult($db_result)
    {
        global $db;
        if(!$db_result&&$db->error)
        {
            error_log($db->error);        
//            die('***~error: database error: '.$db->error);
            die(nf());
        }
    }

    function db() {
        global $db;
        if($db)
        {
            return $db;
        }
        
        $db = new mysqli("localhost", "root", "", "books");
        if (mysqli_connect_errno()){
            error_log('***~err: Не удалось соединиться с БД :'.$db->error());
            exit;
        }
        $db->set_charset("utf8");

        return $db;
    }
    
    $base = "C:/wamp/www/";
    $baseUrl = "http://".gethostbyname(null)."/"; 
    function pbid($bid, $ch) {
        return "books/".$bid."/chaptersAudio/".$ch."_crypt.mp3";
    }
    function ptxt($bid, $ch) {
        return "books/".$bid."/chaptersAudio/".$ch."chapter.txt";
    }

    function pmeta($bid) {
    
        return "books/".$bid."/bookMeta.xml";
    }

    function pimg($bid) {
    
        return "books/".$bid."/BookImage.jpg";
    }
    
    function imgex($bid)
    {
        $path = pimg($bid);
        global $base;
        return file_exists($base.$path) ? $base.$path : null;
    }
    
    function metaex($bid) {
        $path = pmeta($bid);
        global $base;
        return file_exists($base.$path) ? $base.$path : null;
    }
    
    function chaex($bid, $ch) {

        $path = pbid($bid, $ch);
        $pathtxt = ptxt($bid, $ch);    
        global $base;
        return file_exists($base.$path) && file_exists($base.$pathtxt) ? $path : null;
    }

    function nf() // not found
    {
        header("HTTP/1.0 404 Not Found");
        header('Content-Type: text/xml; charset=utf-8');   
        echo '<r><error>404</error></r>';
    }

    function ss($var) // sanitize string
    {
        $var = htmlspecialchars($var, ENT_QUOTES, 'UTF-8');
        $var = strip_tags($var);

        if(get_magic_quotes_gpc())
            $var = stripslashes($var);

        return db()->real_escape_string($var);
    }
?>