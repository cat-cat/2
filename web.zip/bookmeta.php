<?php
include_once 'func.php';


 isset($_GET['bid']) && isset($_GET['dev']) or die(nf());
 
 $bid = ss($_GET['bid']);
 $dev = ss($_GET['dev']);
        
 $path = metaex($bid) or die(nf());

 function bt() {
global $bid;
global $dev;
$res = db()->query("SELECT is_bought FROM books_bought WHERE user_id=0 AND device_id='$dev' AND book_id='$bid'");
checkDBResult($res);
    $row = $res->fetch_assoc();
    if(!$row)
        return 'no';// no records yet for this book
        
    $is_bought = (int) $row['is_bought'];

     return $is_bought ? 'yes' : 'no';
 }
 $bt = bt();
    // notify user on new message

header("Bought: $bt");
header('Content-Type: text/xml; charset=utf-8');   
echo file_get_contents($path);
?>