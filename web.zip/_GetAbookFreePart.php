<?php
header('Content-type: text/xml; charset=utf-8');
echo gethostbyname(null);
//echo <<<_END
//<abooks><file_length>840</file_length></abooks>
//_END;
?>
