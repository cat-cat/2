<?php
$url = "urltoimage";
  header("HTTP/1.1 302 Found");
  header("Location: $url");
?>
