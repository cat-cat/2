<?php
include_once 'func.php';
//$url = "urltoimage";
//  header("HTTP/1.1 302 Found");
//  header("Location: $url");


 isset($_GET['bid']) or die(nf());

    $bid = ss($_GET['bid']);

    $path = imgex($bid) or die(nf());
    
header('Content-Type: image/jpeg');   
echo file_get_contents($path);
?>